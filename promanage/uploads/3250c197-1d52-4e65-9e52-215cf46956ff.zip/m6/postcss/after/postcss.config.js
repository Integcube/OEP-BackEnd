module.exports = {
  plugins: {
    '@csstools/postcss-sass': {},
    tailwindcss: {},
    autoprefixer: {}
  }
};