import { createApp } from 'vue'
import App from './App.vue'
import "./app.css";

createApp(App).mount('#app')
